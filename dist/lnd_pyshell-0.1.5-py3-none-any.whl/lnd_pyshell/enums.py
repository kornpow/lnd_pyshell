# enums.py
from enum import Enum

class ChannelCloseSummaryClosureType(Enum):
	COOPERATIVE_CLOSE
	LOCAL_FORCE_CLOSE
	REMOTE_FORCE_CLOSE
	BREACH_CLOSE
	FUNDING_CANCELED
	ABANDONED

class ChannelEventUpdateUpdateType(Enum):
	OPEN_CHANNEL
	CLOSED_CHANNEL
	ACTIVE_CHANNEL
	INACTIVE_CHANNEL
	PENDING_OPEN_CHANNEL

class FailureFailureCode(Enum):
	RESERVED
	INCORRECT_OR_UNKNOWN_PAYMENT_DETAILS
	INCORRECT_PAYMENT_AMOUNT
	FINAL_INCORRECT_CLTV_EXPIRY
	FINAL_INCORRECT_HTLC_AMOUNT
	FINAL_EXPIRY_TOO_SOON
	INVALID_REALM
	EXPIRY_TOO_SOON
	INVALID_ONION_VERSION
	INVALID_ONION_HMAC
	INVALID_ONION_KEY
	AMOUNT_BELOW_MINIMUM
	FEE_INSUFFICIENT
	INCORRECT_CLTV_EXPIRY
	CHANNEL_DISABLED
	TEMPORARY_CHANNEL_FAILURE
	REQUIRED_NODE_FEATURE_MISSING
	REQUIRED_CHANNEL_FEATURE_MISSING
	UNKNOWN_NEXT_PEER
	TEMPORARY_NODE_FAILURE
	PERMANENT_NODE_FAILURE
	PERMANENT_CHANNEL_FAILURE
	EXPIRY_TOO_FAR
	MPP_TIMEOUT
	INTERNAL_FAILURE
	UNKNOWN_FAILURE
	UNREADABLE_FAILURE

class ForceClosedChannelAnchorState(Enum):
	LIMBO
	RECOVERED
	LOST

class HTLCAttemptHTLCStatus(Enum):

class InvoiceInvoiceState(Enum):

class PaymentPaymentStatus(Enum):
	

class PeerEventEventType(Enum):


class PeerSyncType(Enum):

class lnrpcAddressType(Enum):

class lnrpcCommitmentType(Enum):

class lnrpcFeatureBit(Enum):

class lnrpcInitiator(Enum):

class lnrpcInvoiceHTLCState(Enum):

class lnrpcNodeMetricType(Enum):

class lnrpcPaymentFailureReason(Enum):


class lnrpcResolutionOutcome(Enum):


class lnrpcResolutionType(Enum):


class lnrpcPaymentPaymentStatus(Enum):


class routerrpcFailureDetail(Enum):


class routerrpcHtlcEventEventType(Enum):


class routerrpcPaymentState(Enum):

class routerrpcResolveHoldForwardAction(Enum):

class walletrpcWitnessType(Enum):
