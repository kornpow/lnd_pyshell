# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lnd_pyshell']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.1.2,<2.0.0',
 'pyqrcode>=1.2.1,<2.0.0',
 'requests>=2.24.0,<3.0.0',
 'rich>=7.0.0,<8.0.0']

entry_points = \
{'console_scripts': ['lnd_pyshell = lnd_pyshell.lnd_rest:main']}

setup_kwargs = {
    'name': 'lnd-pyshell',
    'version': '0.1.6',
    'description': '',
    'long_description': None,
    'author': 'Kornpow',
    'author_email': 'test@email.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.1,<4.0',
}


setup(**setup_kwargs)
