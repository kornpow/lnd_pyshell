from base64 import b64encode
from requests import Session
import urllib3
import codecs

class LNDAPISession(Session):

    def __init__(self, *args, **kwargs):
        """
        Creates a new CoreAPISession instance.
        """
        super(LNDAPISession, self).__init__(*args, **kwargs)
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self.headers.update({
            'Accept-Charset': 'utf-8',
            'Content-Type': 'text/plain',
        })

    # def init_basic_auth(self, username, password):
    #     credentials = b64encode('{}:{}'.format(username, password).encode())
    #     self.headers.update({
    #         'Authorization': 'Basic {}'.format(credentials.decode())
    #     })

    def init_auth(self):
        mac = os.getenv("MAC","error")
        tls = os.getenv("TLS","error")
        if "error" in [mac, tls]:
            print("Environment variable issue.")
        
        self.mac = mac
        self.tls = tls
        self.init_mac()
        self.init_tls()

    def init_mac(self):
        self.headers.update({
            "Grpc-Metadata-macaroon": self.mac
        })

    def init_tls(self):
        # cert_bytes = bytes.fromhex(self.tls)
        # fp = tempfile.NamedTemporaryFile()
        # fn = fp.name
        # fp.write(cert_bytes)
        # fp.seek(0)
        # cert_path = fn
        f = io.StringIO(codecs.decode(self.tls, encoding="hex").decode())
        self.verify = f.read()
    

__all__ = ['LNDAPISession']