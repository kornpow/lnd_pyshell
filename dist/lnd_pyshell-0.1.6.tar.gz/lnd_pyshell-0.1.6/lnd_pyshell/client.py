import random
import string
import time
from typing import List, Union
from urllib.parse import urljoin
import os

import lnd_pyshell.utils as utils
from .exceptions import handle_error_response
from .session import LNDAPISession


class BaseAPI(object):
    # TODO: Update these variables
    def __init__(self, host="0.0.0.0:8080", macaroon=None, certfile=None):
        """
        Instantiate a new API client.
        Args:
            macaroon (hex str): Hex encoded "passcode" to operate LND.
            certfile (hex str): Path to certificate file to verify for TLS
                connections (mostly untested).
        """

        if host:
            self.host = host

        self.session = LNDAPISession()

        self.session.init_auth()

    def url(self, path):
        return urljoin(self.host, path)

    @staticmethod
    def _xact_name():
        return "TX_{}".format("".join(random.choices(string.ascii_uppercase + string.digits, k=6)))

    def _request(self, method, url, data={}, request_id: int = 0):
        resp = self.session.request(method, self.url(url), json=data)

        if resp.status_code >= 400:
            handle_error_response(resp)

        return resp.json()


class LndAPI(BaseAPI):
    host = "http://192.168.1.12:8080"
